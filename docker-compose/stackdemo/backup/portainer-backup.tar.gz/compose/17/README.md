This is a repository for creating a docker swarm via IAC.
